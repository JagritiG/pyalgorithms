Pyalgorithms - An Algorithmic Data Analysis Library
--------------------------------------------------------------------------------------------------
This library covers basic Data structures and Algorithms, Probabilistic and Statistical Algorithms,
Math Algorithms, and Machine Learning algorithms.


Features:
--------------------------------------------------------------------------------------------------
Easy to use


Installation:
--------------------------------------------------------------------------------------------------
Run the following command in your terminal to install pyalgorithms

pip3 install pyalgorithms

Or you can download the sourcecode and install the package using

python setup.py install


User Guide:
--------------------------------------------------------------------------------------------------






Tests:
--------------------------------------------------------------------------------------------------
Run the following command to test all the tests defined in tests/ directory

